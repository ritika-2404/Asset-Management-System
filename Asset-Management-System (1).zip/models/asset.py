from config import CONN

def get_all_assets():
    cursor = CONN.cursor()
    cursor.execute("SELECT * FROM ASSET")
    rows = cursor.fetchall()
    result = [dict(zip([col[0] for col in cursor.description], row)) for row in rows]
    cursor.close()
    return result

def add_asset(data):
    cursor = CONN.cursor()
    cursor.execute("""
        INSERT INTO ASSET (asset_name, category, purchase_date, purchase_price, current_value, status)
        VALUES (:1, :2, :3, :4, :5, :6)
    """, (data['asset_name'], data['category'], data['purchase_date'], data['purchase_price'], data['current_value'], data['status']))
    CONN.commit()
    cursor.close()
