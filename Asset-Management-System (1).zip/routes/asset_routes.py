from flask import Blueprint, request, jsonify
from models.asset import get_all_assets, add_asset

asset_bp = Blueprint('asset_bp', __name__)

@asset_bp.route('/', methods=['GET'])
def list_assets():
    return jsonify(get_all_assets())

@asset_bp.route('/', methods=['POST'])
def create_asset():
    data = request.json
    add_asset(data)
    return jsonify({"message": "Asset added successfully"})
